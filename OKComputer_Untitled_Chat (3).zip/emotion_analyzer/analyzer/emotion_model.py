"""
Эмоция талдау моделі
Қазақ және орыс тілдеріндегі мәтіндерді талдайды
"""

import re
import numpy as np
from typing import Dict, List, Tuple, Optional
from collections import Counter
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification


class EmotionAnalyzer:
    """Көпкластық эмоция талдау класы"""
    
    # Эмоциялар картасы
    EMOTIONS = {
        'радость': {'emoji': '😊', 'color': '#FFD93D', 'name_kk': 'Қуаныш', 'name_ru': 'Радость'},
        'грусть': {'emoji': '😢', 'color': '#6B7AA1', 'name_kk': 'Мұң', 'name_ru': 'Грусть'},
        'гнев': {'emoji': '😠', 'color': '#E74C3C', 'name_kk': 'Ашу', 'name_ru': 'Гнев'},
        'страх': {'emoji': '😨', 'color': '#9B59B6', 'name_kk': 'Қорқыныш', 'name_ru': 'Страх'},
        'удивление': {'emoji': '😲', 'color': '#3498DB', 'name_kk': 'Таң қалу', 'name_ru': 'Удивление'},
        'отвращение': {'emoji': '🤢', 'color': '#2ECC71', 'name_kk': 'Жиіркеніш', 'name_ru': 'Отвращение'},
        'нейтральный': {'emoji': '😐', 'color': '#95A5A6', 'name_kk': 'Бейтарап', 'name_ru': 'Нейтральный'},
        'любовь': {'emoji': '❤️', 'color': '#E91E63', 'name_kk': 'Махаббат', 'name_ru': 'Любовь'},
    }
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.model_loaded = False
        self.max_length = 512
        self._load_model()
    
    def _load_model(self):
        """Модельді жүктеу"""
        try:
            # Рус тіліндегі эмоция талдау моделі
            model_name = "cointegrated/rubert-tiny2-cedemotions"
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            self.model = AutoModelForSequenceClassification.from_pretrained(model_name)
            self.model.eval()
            self.model_loaded = True
            print(f"Модель жүктелді: {model_name}")
        except Exception as e:
            print(f"Модельді жүктеу қатесі: {e}")
            # Резервтік модель немесе күтілуде
            self.model_loaded = False
    
    def detect_language(self, text: str) -> str:
        """Мәтін тілін анықтау"""
        # Қазақ әріптерін тексеру
        kazakh_chars = set('әіңғүұқөһӘІҢҒҮҰҚӨҺ')
        # Орыс әріптерін тексеру
        russian_chars = set('ёйцукенгшщзхъфывапролджэячсмитьбюЁЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ')
        
        text_chars = set(text.lower())
        
        kazakh_count = len(text_chars & kazakh_chars)
        russian_count = len(text_chars & russian_chars)
        
        if kazakh_count > 0:
            return 'kk'
        elif russian_count > 0:
            return 'ru'
        else:
            return 'ru'  # Әдепкі - орыс тілі
    
    def split_into_sentences(self, text: str, lang: str = 'ru') -> List[str]:
        """Мәтінді сөйлемдерге бөлу"""
        if lang == 'kk':
            # Қазақ тіліндегі сөйлем ажыратқыштар
            sentences = re.split(r'[.!?]+\s+', text)
        else:
            # Орыс тіліндегі сөйлем ажыратқыштар
            sentences = re.split(r'[.!?]+\s+', text)
        
        # Бос сөйлемдерді өшіру
        sentences = [s.strip() for s in sentences if s.strip()]
        return sentences
    
    def chunk_text(self, text: str, max_tokens: int = 512) -> List[str]:
        """Ұзын мәтінді бөліктерге бөлу"""
        if not self.tokenizer:
            return [text[:2000]]  # Қолмен шектеу
        
        tokens = self.tokenizer.encode(text, add_special_tokens=False)
        
        if len(tokens) <= max_tokens:
            return [text]
        
        chunks = []
        sentences = self.split_into_sentences(text)
        current_chunk = ""
        current_tokens = 0
        
        for sentence in sentences:
            sentence_tokens = len(self.tokenizer.encode(sentence, add_special_tokens=False))
            
            if current_tokens + sentence_tokens > max_tokens:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence
                current_tokens = sentence_tokens
            else:
                current_chunk += " " + sentence
                current_tokens += sentence_tokens
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks if chunks else [text[:2000]]
    
    def predict(self, text: str, lang: str = 'auto') -> Dict:
        """Мәтін үшін эмоция болжамын жасау"""
        if not text or not text.strip():
            return self._get_default_result()
        
        # Тілді анықтау
        if lang == 'auto':
            lang = self.detect_language(text)
        
        # Модель жүктелмеген болса, күтілуде нәтиже
        if not self.model_loaded or self.model is None:
            return self._get_mock_result(text, lang)
        
        try:
            # Ұзын мәтінді бөліктерге бөлу
            chunks = self.chunk_text(text, self.max_length - 10)
            
            all_probabilities = []
            sentence_results = []
            
            # Әр бөлікті талдау
            for chunk in chunks:
                chunk_result = self._analyze_chunk(chunk, lang)
                all_probabilities.append(chunk_result['probabilities'])
                
                # Сөйлем деңгейінде талдау
                sentences = self.split_into_sentences(chunk, lang)
                for sent in sentences[:3]:  # Әр бөліктен 3 сөйлем
                    sent_result = self._analyze_chunk(sent, lang)
                    sentence_results.append({
                        'text': sent,
                        'emotion': sent_result['primary_emotion'],
                        'confidence': sent_result['confidence'],
                        'emoji': self.EMOTIONS.get(sent_result['primary_emotion'], {}).get('emoji', '😐')
                    })
            
            # Ықтималдыларды орташа есептеу
            avg_probabilities = self._aggregate_probabilities(all_probabilities)
            
            # Негізгі эмоцияны анықтау
            primary_emotion = max(avg_probabilities, key=avg_probabilities.get)
            confidence = avg_probabilities[primary_emotion]
            
            return {
                'primary_emotion': primary_emotion,
                'confidence': confidence,
                'probabilities': avg_probabilities,
                'sentence_results': sentence_results[:10],  # 10 сөйлемге шектеу
                'language': lang,
                'sentence_count': len(self.split_into_sentences(text, lang))
            }
            
        except Exception as e:
            print(f"Талдау қатесі: {e}")
            return self._get_mock_result(text, lang)
    
    def _analyze_chunk(self, text: str, lang: str) -> Dict:
        """Бір бөлікті талдау"""
        try:
            inputs = self.tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=self.max_length,
                padding=True
            )
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=1)
                
            probabilities = probs[0].numpy()
            
            # Модель эмоциялары
            model_emotions = ['радость', 'грусть', 'гнев', 'страх', 'удивление', 'отвращение', 'нейтральный']
            
            # Ықтималдыларды сәйкестендіру
            prob_dict = {}
            for i, emotion in enumerate(model_emotions):
                if i < len(probabilities):
                    prob_dict[emotion] = float(probabilities[i])
                else:
                    prob_dict[emotion] = 0.0
            
            # Любовь эмоциясын қосу (басқа эмоциялар негізінде)
            if 'любовь' not in prob_dict:
                prob_dict['любовь'] = 0.05
            
            # Нормализация
            total = sum(prob_dict.values())
            if total > 0:
                prob_dict = {k: v/total for k, v in prob_dict.items()}
            
            primary_emotion = max(prob_dict, key=prob_dict.get)
            confidence = prob_dict[primary_emotion]
            
            return {
                'primary_emotion': primary_emotion,
                'confidence': confidence,
                'probabilities': prob_dict
            }
            
        except Exception as e:
            print(f"Бөлік талдау қатесі: {e}")
            return self._get_default_result()
    
    def _aggregate_probabilities(self, probabilities_list: List[Dict]) -> Dict:
        """Бірнеше ықтималдыларды ортаға қосу"""
        if not probabilities_list:
            return self._get_default_probabilities()
        
        result = {}
        all_emotions = set()
        for probs in probabilities_list:
            all_emotions.update(probs.keys())
        
        for emotion in all_emotions:
            values = [probs.get(emotion, 0) for probs in probabilities_list]
            result[emotion] = np.mean(values)
        
        # Нормализация
        total = sum(result.values())
        if total > 0:
            result = {k: v/total for k, v in result.items()}
        
        return result
    
    def _get_default_result(self) -> Dict:
        """Әдепкі нәтиже"""
        return {
            'primary_emotion': 'нейтральный',
            'confidence': 0.0,
            'probabilities': self._get_default_probabilities(),
            'sentence_results': [],
            'language': 'ru',
            'sentence_count': 0
        }
    
    def _get_default_probabilities(self) -> Dict:
        """Әдепкі ықтималдылар"""
        return {emotion: 1.0/len(self.EMOTIONS) for emotion in self.EMOTIONS.keys()}
    
    def _get_mock_result(self, text: str, lang: str) -> Dict:
        """Күтілуде нәтиже (модель жүктелмеген кезде)"""
        # Мәтін негізінде жеңіл эвристика
        text_lower = text.lower()
        
        # Оң сөздер
        positive_words = ['қуаныш', 'радость', 'счастье', 'бақыт', 'сүйікті', 'прекрасно', 'отлично', 'замечательно', 'қайырлы', 'жақсы']
        # Теріс сөздер
        negative_words = ['ашу', 'гнев', 'мұң', 'грусть', 'қорқыныш', 'страх', 'жаман', 'плохо', 'өкініш', 'жиіркеніш']
        
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            primary = 'радость'
            confidence = min(0.5 + positive_count * 0.1, 0.9)
        elif negative_count > positive_count:
            primary = 'грусть'
            confidence = min(0.5 + negative_count * 0.1, 0.9)
        else:
            primary = 'нейтральный'
            confidence = 0.6
        
        probabilities = self._get_default_probabilities()
        probabilities[primary] = confidence
        
        # Қалған ықтималдыларды қайта бөлу
        remaining = 1.0 - confidence
        other_emotions = [e for e in probabilities.keys() if e != primary]
        for emotion in other_emotions:
            probabilities[emotion] = remaining / len(other_emotions)
        
        sentences = self.split_into_sentences(text, lang)
        sentence_results = []
        for sent in sentences[:5]:
            sentence_results.append({
                'text': sent,
                'emotion': primary,
                'confidence': confidence * 0.9,
                'emoji': self.EMOTIONS.get(primary, {}).get('emoji', '😐')
            })
        
        return {
            'primary_emotion': primary,
            'confidence': confidence,
            'probabilities': probabilities,
            'sentence_results': sentence_results,
            'language': lang,
            'sentence_count': len(sentences)
        }
    
    def get_emotion_info(self, emotion_key: str, lang: str = 'ru') -> Dict:
        """Эмоция туралы ақпарат алу"""
        emotion_data = self.EMOTIONS.get(emotion_key, self.EMOTIONS['нейтральный'])
        return {
            'key': emotion_key,
            'emoji': emotion_data['emoji'],
            'color': emotion_data['color'],
            'name': emotion_data['name_kk'] if lang == 'kk' else emotion_data['name_ru']
        }


# Глобальды модель нұсқасы
_emotion_analyzer = None

def get_emotion_analyzer() -> EmotionAnalyzer:
    """Бір мезгілде қолданылатын модель нұсқасын алу"""
    global _emotion_analyzer
    if _emotion_analyzer is None:
        _emotion_analyzer = EmotionAnalyzer()
    return _emotion_analyzer
