from django.urls import path
from . import views

app_name = 'analyzer'

urlpatterns = [
    # Басты беттер
    path('', views.home, name='home'),
    path('history/', views.history, name='history'),
    path('about/', views.about, name='about'),
    
    # API endpoints
    path('api/predict/', views.api_predict, name='api_predict'),
    path('api/feedback/', views.api_feedback, name='api_feedback'),
    path('api/history/stats/', views.api_history_stats, name='api_history_stats'),
    path('api/history/delete/<int:history_id>/', views.api_delete_history, name='api_delete_history'),
]
