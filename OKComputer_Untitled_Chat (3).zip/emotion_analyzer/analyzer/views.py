import json
import uuid
from datetime import datetime
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.db.models import Count, Avg
from django.conf import settings

from .models import AnalysisHistory, Feedback, EmotionModelInfo
from .emotion_model import get_emotion_analyzer


def get_session_key(request):
    """Сессия кілтін алу немесе жасау"""
    if not request.session.session_key:
        request.session.create()
    return request.session.session_key


def home(request):
    """Басты бет"""
    context = {
        'demo_text_kk': "Бүгін керемет күн! Мен өте бақыттымын. Досыммен кездесіп, тамаша уақыт өткіздім.",
        'demo_text_ru': "Сегодня замечательный день! Я очень счастлив. Встретился с другом и прекрасно провел время.",
    }
    return render(request, 'analyzer/home.html', context)


def history(request):
    """Талдау тарихы беті"""
    session_key = get_session_key(request)
    analyses = AnalysisHistory.objects.filter(session_key=session_key)[:20]
    
    # Статистика
    stats = {
        'total': analyses.count(),
        'by_emotion': {},
        'avg_confidence': 0
    }
    
    if analyses.exists():
        emotion_counts = analyses.values('primary_emotion').annotate(count=Count('id'))
        stats['by_emotion'] = {item['primary_emotion']: item['count'] for item in emotion_counts}
        stats['avg_confidence'] = analyses.aggregate(avg=Avg('confidence'))['avg'] or 0
    
    context = {
        'analyses': analyses,
        'stats': stats
    }
    return render(request, 'analyzer/history.html', context)


def about(request):
    """Модель туралы бет"""
    model_info = EmotionModelInfo.objects.filter(is_active=True).first()
    
    if not model_info:
        # Әдепкі ақпарат
        model_info = {
            'name': 'RuBERT-Tiny2-CEditions',
            'description': 'Transformer негізіндегі эмоция тану моделі. Рус тіліндегі мәтіндерді талдауға арналған.',
            'emotions': [
                {'key': 'радость', 'name': 'Радость / Қуаныш', 'emoji': '😊', 'color': '#FFD93D'},
                {'key': 'грусть', 'name': 'Грусть / Мұң', 'emoji': '😢', 'color': '#6B7AA1'},
                {'key': 'гнев', 'name': 'Гнев / Ашу', 'emoji': '😠', 'color': '#E74C3C'},
                {'key': 'страх', 'name': 'Страх / Қорқыныш', 'emoji': '😨', 'color': '#9B59B6'},
                {'key': 'удивление', 'name': 'Удивление / Таң қалу', 'emoji': '😲', 'color': '#3498DB'},
                {'key': 'отвращение', 'name': 'Отвращение / Жиіркеніш', 'emoji': '🤢', 'color': '#2ECC71'},
                {'key': 'нейтральный', 'name': 'Нейтральный / Бейтарап', 'emoji': '😐', 'color': '#95A5A6'},
                {'key': 'любовь', 'name': 'Любовь / Махаббат', 'emoji': '❤️', 'color': '#E91E63'},
            ],
            'limitations': '''
                • Сарказм және иронияны түсінбеуі мүмкін
                • Сленг және диалект сөздерді дұрыс талдамайды
                • Аралас тілдегі мәтіндерде қателесуі мүмкін
                • Ұзақ контексті толық түсінбеуі мүмкін
                • Эмоциялар субъективті болуы мүмкін
            '''
        }
    
    context = {
        'model_info': model_info
    }
    return render(request, 'analyzer/about.html', context)


@csrf_exempt
@require_http_methods(["POST"])
def api_predict(request):
    """API endpoint для предсказания эмоций"""
    try:
        data = json.loads(request.body)
        text = data.get('text', '').strip()
        lang = data.get('lang', 'auto')
        
        # Валидация
        if not text:
            return JsonResponse({
                'success': False,
                'error': 'Мәтін енгізілмеген',
                'error_code': 'EMPTY_TEXT'
            }, status=400)
        
        if len(text) < 3:
            return JsonResponse({
                'success': False,
                'error': 'Мәтін тым қысқа (кемінде 3 таңба)',
                'error_code': 'TOO_SHORT'
            }, status=400)
        
        if len(text) > 10000:
            return JsonResponse({
                'success': False,
                'error': 'Мәтін тым ұзын (10,000 таңбадан аспауы керек)',
                'error_code': 'TOO_LONG'
            }, status=400)
        
        # Модельді алу
        analyzer = get_emotion_analyzer()
        
        # Талдау
        result = analyzer.predict(text, lang)
        
        # Тарихқа сақтау
        session_key = get_session_key(request)
        history_entry = AnalysisHistory.objects.create(
            text_snippet=text[:200],
            language=lang,
            primary_emotion=result['primary_emotion'],
            confidence=result['confidence'],
            probabilities=result['probabilities'],
            sentence_count=result['sentence_count'],
            session_key=session_key
        )
        
        # Эмоциялар туралы қосымша ақпарат
        emotion_info = {}
        for emotion_key in result['probabilities'].keys():
            emotion_info[emotion_key] = analyzer.get_emotion_info(emotion_key, result['language'])
        
        # Жауап
        response_data = {
            'success': True,
            'data': {
                'id': history_entry.id,
                'primary_emotion': result['primary_emotion'],
                'confidence': result['confidence'],
                'probabilities': result['probabilities'],
                'emotion_info': emotion_info,
                'sentence_results': result['sentence_results'],
                'language': result['language'],
                'sentence_count': result['sentence_count'],
                'timestamp': history_entry.created_at.isoformat()
            }
        }
        
        return JsonResponse(response_data)
        
    except json.JSONDecodeError:
        return JsonResponse({
            'success': False,
            'error': 'Жарамсыз JSON форматы',
            'error_code': 'INVALID_JSON'
        }, status=400)
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': f'Сервер қатесі: {str(e)}',
            'error_code': 'SERVER_ERROR'
        }, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def api_feedback(request):
    """API endpoint для обратной связи"""
    try:
        data = json.loads(request.body)
        analysis_id = data.get('analysis_id')
        feedback_type = data.get('feedback_type')
        comment = data.get('comment', '')
        
        if not analysis_id or not feedback_type:
            return JsonResponse({
                'success': False,
                'error': 'analysis_id және feedback_type қажет'
            }, status=400)
        
        analysis = get_object_or_404(AnalysisHistory, id=analysis_id)
        
        Feedback.objects.create(
            analysis=analysis,
            feedback_type=feedback_type,
            comment=comment
        )
        
        return JsonResponse({
            'success': True,
            'message': 'Кері байланыс сақталды'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_http_methods(["DELETE"])
def api_delete_history(request, history_id):
    """API endpoint для удаления записи из истории"""
    try:
        session_key = get_session_key(request)
        history_entry = get_object_or_404(AnalysisHistory, id=history_id, session_key=session_key)
        history_entry.delete()
        
        return JsonResponse({
            'success': True,
            'message': 'Жазба жойылды'
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


def api_history_stats(request):
    """API endpoint для получения статистики истории"""
    session_key = get_session_key(request)
    analyses = AnalysisHistory.objects.filter(session_key=session_key)
    
    stats = {
        'total': analyses.count(),
        'by_emotion': {},
        'by_language': {},
        'avg_confidence': 0,
        'recent': []
    }
    
    if analyses.exists():
        # Эмоциялар бойынша
        emotion_counts = analyses.values('primary_emotion').annotate(count=Count('id'))
        stats['by_emotion'] = {item['primary_emotion']: item['count'] for item in emotion_counts}
        
        # Тілдер бойынша
        lang_counts = analyses.values('language').annotate(count=Count('id'))
        stats['by_language'] = {item['language']: item['count'] for item in lang_counts}
        
        # Орташа сенімділік
        stats['avg_confidence'] = analyses.aggregate(avg=Avg('confidence'))['avg'] or 0
        
        # Соңғы талдаулар
        recent = analyses[:5]
        stats['recent'] = [{
            'id': a.id,
            'text_snippet': a.text_snippet,
            'primary_emotion': a.primary_emotion,
            'confidence': a.confidence,
            'created_at': a.created_at.isoformat()
        } for a in recent]
    
    return JsonResponse({
        'success': True,
        'data': stats
    })
