/**
 * Emotion AI - History JavaScript
 * History page functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    initHistory();
});

function initHistory() {
    initDeleteButtons();
    initViewButtons();
    initClearAllButton();
    initEmotionDistributionChart();
}

/**
 * Initialize delete buttons
 */
function initDeleteButtons() {
    const deleteButtons = document.querySelectorAll('.delete-item');
    
    deleteButtons.forEach(btn => {
        btn.addEventListener('click', async function() {
            const id = this.dataset.id;
            const item = this.closest('.history-item');
            
            if (!confirm('Бұл жазбаны жойғыңыз келе ме?')) return;
            
            try {
                await window.EmotionAI.apiCall(`/api/history/delete/${id}/`, {
                    method: 'DELETE'
                });
                
                // Animate removal
                item.style.transition = 'all 0.3s ease';
                item.style.opacity = '0';
                item.style.transform = 'translateX(-100%)';
                
                setTimeout(() => {
                    item.remove();
                    updateStats();
                }, 300);
                
                window.EmotionAI.showToast('Жазба жойылды', 'success');
                
            } catch (error) {
                window.EmotionAI.showToast('Қате: ' + error.message, 'error');
            }
        });
    });
}

/**
 * Initialize view buttons
 */
function initViewButtons() {
    const viewButtons = document.querySelectorAll('.view-details');
    const modal = document.getElementById('detailsModal');
    const modalClose = document.getElementById('modalClose');
    const modalBody = document.getElementById('modalBody');
    
    viewButtons.forEach(btn => {
        btn.addEventListener('click', async function() {
            const id = this.dataset.id;
            
            // Show modal with loading
            if (modal) {
                modal.classList.add('active');
                if (modalBody) {
                    modalBody.innerHTML = '<div class="loading-spinner-small"></div>';
                }
            }
            
            try {
                // Fetch history stats to get detailed info
                const response = await window.EmotionAI.apiCall('/api/history/stats/');
                
                if (response.success && response.data.recent) {
                    const analysis = response.data.recent.find(a => a.id == id);
                    
                    if (analysis && modalBody) {
                        modalBody.innerHTML = `
                            <div class="detail-item">
                                <span class="detail-label">Эмоция:</span>
                                <span class="detail-value">${analysis.primary_emotion}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Сенімділік:</span>
                                <span class="detail-value">${window.EmotionAI.formatPercent(analysis.confidence)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Уақыт:</span>
                                <span class="detail-value">${new Date(analysis.created_at).toLocaleString('kk-KZ')}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Мәтін:</span>
                                <p class="detail-text">${escapeHtml(analysis.text_snippet)}</p>
                            </div>
                        `;
                    }
                }
            } catch (error) {
                if (modalBody) {
                    modalBody.innerHTML = `<p class="error-text">Ақпаратты жүктеу қатесі: ${error.message}</p>`;
                }
            }
        });
    });
    
    // Close modal
    if (modalClose) {
        modalClose.addEventListener('click', () => {
            modal?.classList.remove('active');
        });
    }
    
    // Close on overlay click
    const modalOverlay = modal?.querySelector('.modal-overlay');
    if (modalOverlay) {
        modalOverlay.addEventListener('click', () => {
            modal?.classList.remove('active');
        });
    }
    
    // Close on Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal?.classList.contains('active')) {
            modal.classList.remove('active');
        }
    });
}

/**
 * Initialize clear all button
 */
function initClearAllButton() {
    const clearAllBtn = document.getElementById('clearAllBtn');
    
    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', async function() {
            if (!confirm('Барлық тарихты жойғыңыз келе ме? Бұл әрекетті кері қайтару мүмкін емес.')) return;
            
            const historyItems = document.querySelectorAll('.history-item');
            
            try {
                // Delete all items
                const promises = Array.from(historyItems).map(item => {
                    const id = item.dataset.id;
                    return window.EmotionAI.apiCall(`/api/history/delete/${id}/`, {
                        method: 'DELETE'
                    }).catch(() => null);
                });
                
                await Promise.all(promises);
                
                // Animate all removals
                historyItems.forEach((item, index) => {
                    setTimeout(() => {
                        item.style.transition = 'all 0.3s ease';
                        item.style.opacity = '0';
                        item.style.transform = 'translateX(-100%)';
                        setTimeout(() => item.remove(), 300);
                    }, index * 50);
                });
                
                setTimeout(() => {
                    location.reload();
                }, historyItems.length * 50 + 500);
                
                window.EmotionAI.showToast('Барлық тарих жойылды', 'success');
                
            } catch (error) {
                window.EmotionAI.showToast('Қате: ' + error.message, 'error');
            }
        });
    }
}

/**
 * Initialize emotion distribution chart
 */
function initEmotionDistributionChart() {
    const ctx = document.getElementById('emotionDistributionChart');
    if (!ctx || typeof emotionDistribution === 'undefined') return;
    
    const emotions = Object.keys(emotionDistribution);
    const counts = Object.values(emotionDistribution);
    
    // Emotion colors
    const emotionColors = {
        'радость': '#FFD93D',
        'грусть': '#6B7AA1',
        'гнев': '#E74C3C',
        'страх': '#9B59B6',
        'удивление': '#3498DB',
        'отвращение': '#2ECC71',
        'нейтральный': '#95A5A6',
        'любовь': '#E91E63'
    };
    
    const colors = emotions.map(e => emotionColors[e] || '#95A5A6');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: emotions.map(e => e.charAt(0).toUpperCase() + e.slice(1)),
            datasets: [{
                label: 'Талдаулар саны',
                data: counts,
                backgroundColor: colors,
                borderRadius: 8,
                borderSkipped: false,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        color: getComputedStyle(document.body).getPropertyValue('--text-secondary')
                    },
                    grid: {
                        color: getComputedStyle(document.body).getPropertyValue('--border-color')
                    }
                },
                x: {
                    ticks: {
                        color: getComputedStyle(document.body).getPropertyValue('--text-secondary')
                    },
                    grid: { display: false }
                }
            }
        }
    });
}

/**
 * Update statistics
 */
function updateStats() {
    const historyItems = document.querySelectorAll('.history-item');
    const totalCount = document.getElementById('totalCount');
    
    if (totalCount) {
        window.EmotionAI.animateCounter(totalCount, historyItems.length, 500, '');
    }
    
    // If no items left, show empty state
    if (historyItems.length === 0) {
        const historyList = document.querySelector('.history-list');
        if (historyList) {
            historyList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📭</div>
                    <h3>Тарих бос</h3>
                    <p>Әлі ешқандай талдау жасалмаған.</p>
                </div>
            `;
        }
    }
}

/**
 * Escape HTML
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
