"""
Minimal training script to fine-tune a multilingual emotion classifier for KK/RU.

Prereqs (install in a training environment, not necessarily in production):
    pip install transformers datasets accelerate evaluate

Expected CSV columns: text,label
    label values: anger, joy, optimism, sadness, neutral
"""

import argparse
import json
from pathlib import Path
from typing import Dict

import numpy as np
import torch
from datasets import load_dataset
from sklearn.metrics import f1_score
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)

LABEL2ID: Dict[str, int] = {
    "anger": 0,
    "joy": 1,
    "optimism": 2,
    "sadness": 3,
    "neutral": 4,
}
ID2LABEL = {v: k for k, v in LABEL2ID.items()}


def load_data(train_path: str, val_path: str):
    data_files = {"train": train_path, "validation": val_path}
    ds = load_dataset("csv", data_files=data_files)
    ds = ds.filter(lambda x: x.get("text") and x.get("label") in LABEL2ID)
    ds = ds.map(lambda x: {"label_id": LABEL2ID[x["label"]]})
    return ds


def tokenize_dataset(ds, tokenizer, max_length: int = 256):
    def tokenize(batch):
        return tokenizer(
            batch["text"],
            truncation=True,
            padding="max_length",
            max_length=max_length,
        )

    return ds.map(tokenize, batched=True)


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    macro_f1 = f1_score(labels, preds, average="macro")
    return {"macro_f1": macro_f1}


def calibrate_temperature(logits: np.ndarray, labels: np.ndarray, max_iter: int = 100) -> float:
    """Fit a single temperature parameter on validation logits."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logit_t = torch.tensor(logits, dtype=torch.float32, device=device)
    label_t = torch.tensor(labels, dtype=torch.long, device=device)
    temperature = torch.nn.Parameter(torch.ones(1, device=device))
    optimizer = torch.optim.LBFGS([temperature], lr=0.1, max_iter=20)
    loss_fn = torch.nn.CrossEntropyLoss()

    def closure():
        optimizer.zero_grad()
        scaled = logit_t / torch.clamp(temperature, min=1e-6)
        loss = loss_fn(scaled, label_t)
        loss.backward()
        return loss

    for _ in range(max_iter):
        optimizer.step(closure)
    return float(torch.clamp(temperature.detach(), min=1e-6).cpu().item())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_csv", required=True, help="Path to training CSV (text,label)")
    parser.add_argument("--val_csv", required=True, help="Path to validation CSV (text,label)")
    parser.add_argument("--model_name", default="clapAI/roberta-large-multilingual-sentiment")
    parser.add_argument("--output_dir", default="emotion-mbert-kkru")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--batch", type=int, default=16)
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model_name,
        num_labels=len(LABEL2ID),
        label2id=LABEL2ID,
        id2label=ID2LABEL,
    )

    ds = load_data(args.train_csv, args.val_csv)
    tokenized = tokenize_dataset(ds, tokenizer)

    training_args = TrainingArguments(
        output_dir=args.output_dir,
        learning_rate=args.lr,
        per_device_train_batch_size=args.batch,
        per_device_eval_batch_size=args.batch,
        num_train_epochs=args.epochs,
        weight_decay=0.01,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        fp16=torch.cuda.is_available(),
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized["train"],
        eval_dataset=tokenized["validation"],
        compute_metrics=compute_metrics,
        tokenizer=tokenizer,
    )

    trainer.train()
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)

    # Temperature scaling on validation set
    eval_preds = trainer.predict(tokenized["validation"])
    temp = calibrate_temperature(eval_preds.predictions, eval_preds.label_ids)
    temp_path = Path(args.output_dir) / "temperature.json"
    temp_path.write_text(json.dumps({"temperature": temp}, indent=2))
    print(f"Saved temperature={temp:.4f} to {temp_path}")


if __name__ == "__main__":
    main()
