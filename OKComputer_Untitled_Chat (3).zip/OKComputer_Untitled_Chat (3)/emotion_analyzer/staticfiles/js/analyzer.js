/**
 * Emotion AI - Analyzer JavaScript v3
 * Жаңа диаграммалар: Radar, Timeline, Thermometer, Bar, Donut
 */

document.addEventListener('DOMContentLoaded', function() {
    initAnalyzer();
});

// Global chart instances
let barChart = null;
let pieChart = null;
let radarChart = null;
let currentAnalysisId = null;
let analysisHistory = []; // уақыт сызығы үшін

function initAnalyzer() {
    const textInput = document.getElementById('textInput');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const clearBtn = document.getElementById('clearBtn');
    const demoBtn = document.getElementById('demoBtn');

    if (textInput) {
        textInput.addEventListener('input', updateStats);
        textInput.addEventListener('paste', () => setTimeout(updateStats, 0));
    }
    if (analyzeBtn) analyzeBtn.addEventListener('click', analyzeText);
    if (clearBtn) clearBtn.addEventListener('click', clearAll);
    if (demoBtn) demoBtn.addEventListener('click', loadDemoText);

    initChartTabs();
    initExportButtons();
    initFeedbackButtons();
    window.addEventListener('themeChanged', updateChartColors);
}

function updateStats() {
    const text = document.getElementById('textInput')?.value || '';
    const el = (id) => document.getElementById(id);
    if (el('charCount')) el('charCount').textContent = text.length.toLocaleString('kk-KZ');
    if (el('wordCount')) el('wordCount').textContent = text.trim().split(/\s+/).filter(w => w).length.toLocaleString('kk-KZ');
    if (el('sentenceCount')) el('sentenceCount').textContent = text.split(/[.!?]+/).filter(s => s.trim()).length.toLocaleString('kk-KZ');
}

async function analyzeText() {
    const textInput = document.getElementById('textInput');
    const languageSelect = document.getElementById('languageSelect');
    if (!textInput) return;

    const text = textInput.value.trim();
    const lang = languageSelect?.value || 'auto';

    if (!text) { window.EmotionAI.showToast('Мәтінді енгізіңіз', 'warning'); textInput.focus(); return; }
    if (text.length < 3) { window.EmotionAI.showToast('Мәтін тым қысқа', 'warning'); return; }

    window.EmotionAI.showLoading('Мәтін талдануда...');
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        window.EmotionAI.updateProgress(progress);
    }, 200);

    try {
        const response = await window.EmotionAI.apiCall('/api/predict/', {
            method: 'POST',
            body: JSON.stringify({ text, lang })
        });
        clearInterval(progressInterval);
        window.EmotionAI.updateProgress(100);

        if (response.success) {
            currentAnalysisId = response.data.id;
            // Тарихқа қосу (уақыт сызығы үшін)
            analysisHistory.push({
                time: new Date().toLocaleTimeString('kk-KZ', { hour: '2-digit', minute: '2-digit' }),
                emotion: response.data.primary_emotion,
                confidence: response.data.confidence,
                probabilities: response.data.probabilities,
                emotion_info: response.data.emotion_info
            });
            if (analysisHistory.length > 8) analysisHistory.shift();

            displayResults(response.data);
            window.EmotionAI.showToast('Талдау сәтті аяқталды!', 'success');
        } else {
            throw new Error(response.error || 'Талдау қатесі');
        }
    } catch (error) {
        clearInterval(progressInterval);
        window.EmotionAI.hideLoading();
        window.EmotionAI.showToast(error.message, 'error');
    }
}

function displayResults(data) {
    const resultsSection = document.getElementById('resultsSection');
    if (!resultsSection) return;

    const el = (id) => document.getElementById(id);
    const emotionInfo = data.emotion_info[data.primary_emotion];

    if (el('primaryEmoji')) el('primaryEmoji').textContent = emotionInfo?.emoji || '😐';
    if (el('primaryEmotionName')) el('primaryEmotionName').textContent = emotionInfo?.name || data.primary_emotion;
    if (el('primaryPercentage')) el('primaryPercentage').textContent = window.EmotionAI.formatPercent(data.confidence);
    if (el('confidenceFill')) setTimeout(() => { el('confidenceFill').style.width = window.EmotionAI.formatPercent(data.confidence); }, 100);
    if (el('confidenceValue')) el('confidenceValue').textContent = window.EmotionAI.formatPercent(data.confidence);

    updateTopEmotions(data.probabilities, data.emotion_info);
    updateCharts(data.probabilities, data.emotion_info);
    updateRadarChart(data.probabilities, data.emotion_info);
    updateThermometers(data.probabilities, data.emotion_info);
    updateTimelineChart();
    updateSentenceAnalysis(data.sentence_results);

    resultsSection.style.display = 'block';
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => window.EmotionAI.hideLoading(), 500);
}

function updateTopEmotions(probabilities, emotionInfo) {
    const emotionsList = document.getElementById('emotionsList');
    if (!emotionsList) return;
    const sorted = Object.entries(probabilities).sort((a, b) => b[1] - a[1]).slice(0, 5);
    emotionsList.innerHTML = sorted.map(([emotion, prob], index) => {
        const info = emotionInfo[emotion] || { emoji: '😐', color: '#95A5A6', name: emotion };
        return `
        <div class="emotion-item" style="animation: fadeInUp 0.3s ease ${index * 0.1}s both;">
            <span class="emotion-rank">${index + 1}</span>
            <span class="emotion-icon-small">${info.emoji}</span>
            <div class="emotion-details">
                <span class="emotion-label">${info.name}</span>
                <div class="emotion-bar-container">
                    <div class="emotion-bar-fill" style="width: 0%; background-color: ${info.color};"></div>
                </div>
            </div>
            <span class="emotion-percent">${window.EmotionAI.formatPercent(prob)}</span>
        </div>`;
    }).join('');
    setTimeout(() => {
        emotionsList.querySelectorAll('.emotion-bar-fill').forEach((bar, i) => {
            bar.style.width = window.EmotionAI.formatPercent(sorted[i][1]);
        });
    }, 100);
}

// ================================================================
// БАР + DONUT ДИАГРАММАЛАРЫ (бар болған)
// ================================================================
function updateCharts(probabilities, emotionInfo) {
    const sorted = Object.entries(probabilities).sort((a, b) => b[1] - a[1]);
    const labels = sorted.map(([e]) => emotionInfo[e]?.name || e);
    const data   = sorted.map(([, p]) => (p * 100).toFixed(1));
    const colors = sorted.map(([e]) => emotionInfo[e]?.color || '#95A5A6');
    const emojis = sorted.map(([e]) => emotionInfo[e]?.emoji || '😐');

    // Bar
    const barCtx = document.getElementById('barChart');
    if (barCtx) {
        if (barChart) barChart.destroy();
        barChart = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: labels.map((l, i) => `${emojis[i]} ${l}`),
                datasets: [{ label: 'Ықтималдық (%)', data, backgroundColor: colors, borderRadius: 10, borderSkipped: false }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => `${ctx.parsed.y}%` } } },
                scales: {
                    y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%', color: cssVar('--text-secondary') }, grid: { color: cssVar('--border-color') } },
                    x: { ticks: { color: cssVar('--text-secondary') }, grid: { display: false } }
                },
                animation: { duration: 1000, easing: 'easeOutQuart' }
            }
        });
    }

    // Donut
    const pieCtx = document.getElementById('pieChart');
    if (pieCtx) {
        if (pieChart) pieChart.destroy();
        pieChart = new Chart(pieCtx, {
            type: 'doughnut',
            data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 3, borderColor: cssVar('--bg-card') }] },
            options: {
                responsive: true, maintainAspectRatio: false, cutout: '62%',
                plugins: {
                    legend: { position: 'bottom', labels: { usePointStyle: true, padding: 12, color: cssVar('--text-primary') } },
                    tooltip: { callbacks: { label: ctx => ` ${ctx.label}: ${ctx.parsed}%` } }
                },
                animation: { animateRotate: true, duration: 1000 }
            }
        });
    }
}

// ================================================================
// RADAR ДИАГРАММАСЫ — жаңа
// ================================================================
function updateRadarChart(probabilities, emotionInfo) {
    const ctx = document.getElementById('radarChart');
    if (!ctx) return;
    if (radarChart) radarChart.destroy();

    const emotions = Object.keys(probabilities);
    const labels = emotions.map(e => emotionInfo[e]?.name || e);
    const data   = emotions.map(e => +(probabilities[e] * 100).toFixed(1));
    const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--accent-primary').trim() || '#6366f1';

    radarChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels,
            datasets: [{
                label: 'Эмоция деңгейі',
                data,
                backgroundColor: primaryColor + '33',
                borderColor: primaryColor,
                borderWidth: 2,
                pointBackgroundColor: emotions.map(e => emotionInfo[e]?.color || primaryColor),
                pointRadius: 5,
                pointHoverRadius: 7,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true, max: 100,
                    ticks: { display: false },
                    grid: { color: cssVar('--border-color') },
                    pointLabels: {
                        color: cssVar('--text-primary'),
                        font: { size: 12 },
                        callback: (label, index) => `${emotionInfo[emotions[index]]?.emoji || ''} ${label}`
                    }
                }
            },
            plugins: { legend: { display: false } },
            animation: { duration: 800 }
        }
    });
}

// ================================================================
// УАҚЫТ СЫЗЫҒЫ (Timeline) — жаңа
// ================================================================
function updateTimelineChart() {
    const ctx = document.getElementById('timelineChart');
    if (!ctx || analysisHistory.length < 1) return;

    const existing = Chart.getChart(ctx);
    if (existing) existing.destroy();

    const emotionColors = {
        'радость': '#FFD93D', 'грусть': '#6B7AA1', 'гнев': '#E74C3C',
        'страх': '#9B59B6', 'удивление': '#3498DB', 'отвращение': '#2ECC71',
        'нейтральный': '#95A5A6', 'любовь': '#E91E63'
    };
    const emotionEmojis = {
        'радость': '😊', 'грусть': '😢', 'гнев': '😠',
        'страх': '😨', 'удивление': '😲', 'отвращение': '🤢',
        'нейтральный': '😐', 'любовь': '❤️'
    };

    const labels = analysisHistory.map((h, i) => `#${i + 1} ${h.time}`);
    const confidences = analysisHistory.map(h => +(h.confidence * 100).toFixed(1));
    const pointColors = analysisHistory.map(h => emotionColors[h.emotion] || '#95A5A6');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Сенімділік %',
                data: confidences,
                borderColor: '#6366f1',
                backgroundColor: 'rgba(99,102,241,0.08)',
                borderWidth: 2.5,
                pointBackgroundColor: pointColors,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 8,
                pointHoverRadius: 11,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        title: (items) => {
                            const h = analysisHistory[items[0].dataIndex];
                            return `${emotionEmojis[h.emotion] || ''} ${h.emotion}`;
                        },
                        label: (ctx) => ` Сенімділік: ${ctx.parsed.y}%`
                    }
                }
            },
            scales: {
                y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%', color: cssVar('--text-secondary') }, grid: { color: cssVar('--border-color') } },
                x: { ticks: { color: cssVar('--text-secondary'), maxRotation: 30 }, grid: { display: false } }
            },
            animation: { duration: 700 }
        }
    });

    // Тарих кестесін жаңарту
    const historyBody = document.getElementById('timelineHistoryBody');
    if (historyBody) {
        historyBody.innerHTML = [...analysisHistory].reverse().map((h, i) => `
            <tr>
                <td style="color:var(--text-secondary);font-size:0.8rem">#${analysisHistory.length - i}</td>
                <td>${h.time}</td>
                <td><span style="background:${emotionColors[h.emotion]}22;color:${emotionColors[h.emotion]};padding:2px 10px;border-radius:20px;font-size:0.85rem">
                    ${emotionEmojis[h.emotion] || ''} ${h.emotion}
                </span></td>
                <td style="font-weight:600">${(h.confidence * 100).toFixed(1)}%</td>
            </tr>
        `).join('');
    }

    // Timeline бөлімін көрсету
    const timelineSection = document.getElementById('timelineSection');
    if (timelineSection) timelineSection.style.display = analysisHistory.length >= 1 ? 'block' : 'none';
}

// ================================================================
// ТЕРМОМЕТР ДИАГРАММАЛАРЫ — жаңа
// ================================================================
function updateThermometers(probabilities, emotionInfo) {
    const container = document.getElementById('thermometerContainer');
    if (!container) return;

    const sorted = Object.entries(probabilities).sort((a, b) => b[1] - a[1]);

    container.innerHTML = sorted.map(([emotion, prob]) => {
        const info = emotionInfo[emotion] || { emoji: '😐', color: '#95A5A6', name: emotion };
        const pct = (prob * 100).toFixed(1);
        const height = Math.max(pct, 3);
        return `
        <div class="thermo-item">
            <div class="thermo-label-top">${pct}%</div>
            <div class="thermo-tube">
                <div class="thermo-fill" style="height: ${height}%; background: ${info.color}; box-shadow: 0 0 8px ${info.color}66;"></div>
                <div class="thermo-bulb" style="background: ${info.color}; box-shadow: 0 0 10px ${info.color}88;"></div>
            </div>
            <div class="thermo-emoji">${info.emoji}</div>
            <div class="thermo-name">${info.name}</div>
        </div>`;
    }).join('');

    // Анимация
    setTimeout(() => {
        container.querySelectorAll('.thermo-fill').forEach(el => {
            el.style.transition = 'height 1s cubic-bezier(0.34, 1.56, 0.64, 1)';
        });
    }, 50);

    const thermoSection = document.getElementById('thermometerSection');
    if (thermoSection) thermoSection.style.display = 'block';
}

// ================================================================
// CHART TAB-ТАРЫ
// ================================================================
function initChartTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const chartType = this.dataset.chart;
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const bar = document.getElementById('barChart');
            const pie = document.getElementById('pieChart');
            if (bar) bar.style.display = chartType === 'bar' ? 'block' : 'none';
            if (pie) pie.style.display = chartType === 'donut' ? 'block' : 'none';
        });
    });
}

function updateChartColors() {
    const textColor = cssVar('--text-primary');
    const gridColor = cssVar('--border-color');
    [barChart, pieChart, radarChart].forEach(chart => {
        if (!chart) return;
        if (chart.config.type === 'bar') {
            chart.options.scales.x.ticks.color = textColor;
            chart.options.scales.y.ticks.color = textColor;
            chart.options.scales.y.grid.color = gridColor;
        }
        if (chart.config.type === 'doughnut') {
            chart.options.plugins.legend.labels.color = textColor;
        }
        chart.update();
    });
}

// ================================================================
// СӨЙЛЕМ ТАЛДАУЫ
// ================================================================
function updateSentenceAnalysis(sentenceResults) {
    const sentencesList = document.getElementById('sentencesList');
    if (!sentencesList) return;
    if (!sentenceResults?.length) {
        sentencesList.innerHTML = '<p class="text-muted">Сөйлемдер табылмады</p>';
        return;
    }
    sentencesList.innerHTML = sentenceResults.map((r, i) => `
        <div class="sentence-item" style="animation: fadeInUp 0.3s ease ${i * 0.05}s both; border-left-color: ${getEmotionColor(r.emotion)}">
            <span class="sentence-text">${escapeHtml(r.text)}</span>
            <div class="sentence-emotion">
                <span class="sentence-emoji">${r.emoji}</span>
                <span class="sentence-confidence">${window.EmotionAI.formatPercent(r.confidence)}</span>
            </div>
        </div>`
    ).join('');
}

function getEmotionColor(e) {
    return { радость:'#FFD93D', грусть:'#6B7AA1', гнев:'#E74C3C', страх:'#9B59B6',
        удивление:'#3498DB', отвращение:'#2ECC71', нейтральный:'#95A5A6', любовь:'#E91E63' }[e] || '#95A5A6';
}

// ================================================================
// ЭКСПОРТ / FEEDBACK / DEMO
// ================================================================
function initExportButtons() {
    document.getElementById('copyResultBtn')?.addEventListener('click', () => {
        const el = (id) => document.getElementById(id);
        let text = `Эмоция талдауы\n================\n\nНегізгі эмоция: ${el('primaryEmotionName')?.textContent} (${el('primaryPercentage')?.textContent})\n\n`;
        document.querySelectorAll('.emotion-item').forEach(item => {
            text += `- ${item.querySelector('.emotion-label')?.textContent}: ${item.querySelector('.emotion-percent')?.textContent}\n`;
        });
        window.EmotionAI.copyToClipboard(text);
    });
    document.getElementById('exportPngBtn')?.addEventListener('click', () => {
        const rc = document.getElementById('resultsContent');
        if (rc) window.EmotionAI.exportToPNG(rc, 'emotion-analysis.png');
    });
    document.getElementById('exportPdfBtn')?.addEventListener('click', () => {
        window.EmotionAI.exportToPDF('Эмоция талдауы');
    });
}

function initFeedbackButtons() {
    let selectedFeedback = null;
    const pos = document.getElementById('feedbackPositive');
    const neg = document.getElementById('feedbackNegative');
    const comment = document.getElementById('feedbackComment');
    const submitBtn = document.getElementById('submitFeedback');
    const feedbackText = document.getElementById('feedbackText');

    pos?.addEventListener('click', () => { selectedFeedback = 'positive'; pos.classList.add('active'); neg?.classList.remove('active'); if (comment) comment.style.display = 'block'; });
    neg?.addEventListener('click', () => { selectedFeedback = 'negative'; neg.classList.add('active'); pos?.classList.remove('active'); if (comment) comment.style.display = 'block'; });
    submitBtn?.addEventListener('click', async () => {
        if (!selectedFeedback || !currentAnalysisId) return;
        try {
            await window.EmotionAI.apiCall('/api/feedback/', { method: 'POST', body: JSON.stringify({ analysis_id: currentAnalysisId, feedback_type: selectedFeedback, comment: feedbackText?.value || '' }) });
            window.EmotionAI.showToast('Кері байланыс үшін рахмет!', 'success');
            if (comment) comment.style.display = 'none';
            if (feedbackText) feedbackText.value = '';
        } catch (e) { window.EmotionAI.showToast('Қате: ' + e.message, 'error'); }
    });
}

function clearAll() {
    const textInput = document.getElementById('textInput');
    const resultsSection = document.getElementById('resultsSection');
    if (textInput) { textInput.value = ''; textInput.focus(); }
    if (resultsSection) resultsSection.style.display = 'none';
    const timelineSection = document.getElementById('timelineSection');
    if (timelineSection) timelineSection.style.display = 'none';
    updateStats();
    window.EmotionAI.showToast('Тазаланды', 'info');
}

function loadDemoText() {
    const textInput = document.getElementById('textInput');
    const lang = document.getElementById('languageSelect')?.value || 'auto';
    if (!textInput) return;
    let demoText = (typeof demoTexts !== 'undefined')
        ? (lang === 'ru' ? demoTexts.ru : demoTexts.kk)
        : 'Бүгін керемет күн! Мен өте бақыттымын. Досыммен кездесіп, тамаша уақыт өткіздім.';
    textInput.value = '';
    let i = 0;
    const t = setInterval(() => { textInput.value += demoText[i++]; if (i >= demoText.length) { clearInterval(t); updateStats(); } }, 18);
}

// ================================================================
// УТИЛИТАЛАР
// ================================================================
function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}
function escapeHtml(text) {
    const d = document.createElement('div'); d.textContent = text; return d.innerHTML;
}